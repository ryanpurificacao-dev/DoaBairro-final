# Orçamento e hospedagem

## Proposta

O site é estático (HTML, CSS e JavaScript), então GitHub Pages é uma opção adequada para uma demonstração acadêmica. A publicação deverá usar HTTPS e a equipe precisa testar todas as páginas online. A configuração ainda está pendente nesta cópia local.

| Item | Estimativa | Observação |
|---|---:|---|
| Hospedagem estática no plano gratuito elegível do GitHub Pages | R$ 0 | Sujeito aos termos, limites e elegibilidade atuais da conta/repositório. |
| Domínio próprio | Não estimado | Opcional; pesquisar preço atual de extensão e registrador antes de contratar. |
| Desenvolvimento e manutenção do protótipo | Sem custo financeiro estimado | Trabalho acadêmico; não inclui suporte ou monitoramento. |

**Fonte:** [documentação oficial do GitHub Pages](https://docs.github.com/pages/getting-started-with-github-pages/about-github-pages). Confirmar os termos vigentes antes do deploy.

## Justificativa e pendências

Hospedagem estática atende aos arquivos atuais, reduz configuração e pode servir o site por HTTPS. É necessário publicar o repositório correto, configurar Pages, registrar a URL real no README e testar links/recursos pelo endereço público. Não há domínio ou URL de produção atribuídos nesta documentação.
