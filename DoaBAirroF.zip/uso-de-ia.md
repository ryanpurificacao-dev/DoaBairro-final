# Uso de IA e plano de contexto

## Registro

- **Ferramenta:** assistente Copilot usado durante a revisão do projeto.
- **Solicitação recebida:** “veja o que tá faltando para eu entregar esse projeto” e implemente os erros e lacunas de acordo com o roteiro e a rubrica fornecidos.
- **Instruções usadas:** comparar os arquivos do site com o PDF e a planilha da atividade; implementar o escopo que pudesse ser concluído localmente; preservar a transparência sobre limitações e não inventar dados de equipe, URL ou organizações.
- **Aceito:** estrutura das dez páginas, CSS responsivo, busca, navegação móvel, armazenamento local de preferências/rascunho, validação do formulário, conteúdo ODS e documentação.
- **Revisado/corrigido:** os exemplos de campanhas foram identificados como fictícios; o formulário informa que não envia dados; a FAQ foi descrita como baseada em regras, não generativa; custos de domínio e publicação não foram inventados; deploy e participação no GitHub ficaram como pendências explícitas.
- **Integração no site:** FAQ demonstrativa baseada em regras simples em `app.js`, sem API de IA. As respostas e limitações devem ser explicadas pela equipe.

## Plano de contexto para futuras alterações

1. Consultar este README, `docs/escopo.md` e os critérios da rubrica antes de alterar o comportamento.
2. Preservar HTML semântico, foco visível, navegação por teclado, linguagem em português do Brasil e layout móvel.
3. Nunca apresentar exemplos como organizações, notícias, estatísticas ou doações reais sem fonte e confirmação.
4. Não adicionar envio de dados pessoais a serviços externos sem consentimento, política de privacidade e implementação de backend aprovada.
5. Após mudanças, testar links, formulário inválido/válido, persistência local e telas menores; registrar evidências reais no diário.

## Responsabilidade da equipe

O registro não substitui o entendimento do código. Cada integrante deve revisar e explicar as decisões e trechos gerados antes da apresentação. Corrigir este documento se a equipe usar outros prompts, aceitar sugestões adicionais ou rejeitar mudanças.
