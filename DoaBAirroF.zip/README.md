# Documentação da entrega — DoaBairro

## Identificação da equipe

- Pedro Henrrique Araujo — RA 47920742
- Ryan da Purificação de Oliveira — RA 47508442
- João Victor Gomes Santana — RA 47699736
- Adrian Guilherme Viera Gomes — RA 47666188
- Matheus Masayuki — RA 47354267
- Leonardo Fonseca — RA 47354313
- Marcelo Eduardo de Souza Junior — RA 47128828
- Papéis propostos (confirmar com todos):
  - Pedro: coordenação do escopo e diário de bordo.
  - Ryan: conteúdo, referências e ODS.
  - João Victor: integração front-end e JavaScript.
  - Adrian: CSS responsivo e acessibilidade.
  - Matheus: conteúdo e organização dos projetos demonstrativos.
  - Leonardo: testes, validação e evidências.
  - Marcelo: planejamento de GitHub, deploy e apresentação.
- URL publicada com HTTPS: **[pendente de deploy]**
- Repositório GitHub: **[pendente]**
- Data da apresentação: **[confirmar com a equipe]**
- Divisão proposta de papéis: revisar e confirmar com todos antes de apresentar.

## Documentos

- [Escopo e critérios de aceitação](./escopo.md)
- [Diário de bordo](./diario-de-bordo.md)
- [Uso de IA e plano de contexto](./uso-de-ia.md)
- [Melhorias do MVP](./melhorias-mvp.md)
- [Orçamento e hospedagem](./orcamento.md)
- [Testes e evidências](./testes.md)
- [Fonte HTML da apresentação de 14 slides](./apresentacao.html)

## Como abrir e testar

Abra `index.html` em navegador moderno. Não há processo de build. O mapa depende de conexão externa; o rascunho do formulário e a preferência de contraste usam o armazenamento local do navegador. Os dados e campanhas ilustrados são fictícios.

## Exportar a apresentação

Abra `docs/apresentacao.html` no Safari ou Chrome e use **Arquivo → Imprimir → Salvar como PDF**. O HTML já define impressão em formato 16:9 com uma página por slide. Antes de enviar, confira que o PDF contém 14 páginas, desative cabeçalhos/rodapés do navegador e substitua os campos pendentes por informações confirmadas pela equipe.

## Checklist de envio

O roteiro da atividade também pede itens que não podem ser criados ou confirmados apenas nesta cópia local:

- [x] Arquivo [`integrantes.txt`](../integrantes.txt) criado com os nomes e RAs informados.
- [ ] Confirmar a grafia e a completude dos nomes no `.txt`.
- [ ] URL do site publicado em HTTPS, testada em computador e celular.
- [ ] URL do repositório, histórico com contribuições reais de toda a equipe, branch e pelo menos um pull request.
- [ ] Revisar a fonte da apresentação, completar dados reais pendentes e exportar/enviar os slides como `.pdf` ou `.pptx`.
- [x] Capturas da interface local em desktop e celular criadas em `docs/home-desktop.png` e `docs/home-celular.png`.
- [ ] `.zip` com a mesma versão do código que foi publicada; `projeto-doabairro-local.zip` é apenas um pacote local preliminar e deve ser regenerado ou comparado após o deploy.
- [ ] Confirmar com a equipe se os papéis propostos correspondem às contribuições reais.
- [ ] Se houver devolutiva do MVP, relacionar cada apontamento à correção e anexar evidências; a equipe informou que não tem apontamentos específicos disponíveis.
- [x] Nu HTML Checker: 10 páginas validadas em 13/11/2026, sem erros ou avisos.
- [ ] Ensaiar a demonstração de 20 minutos e preparar um plano B offline.
- [ ] Enviar os arquivos no Blackboard conforme o prazo indicado pela disciplina.

Não enviar esta lista como substituto dos arquivos obrigatórios. As URLs, os dados da equipe e as evidências precisam ser preenchidos pela equipe.
