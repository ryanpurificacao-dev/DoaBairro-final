// Interações demonstrativas do projeto; nenhum dado é enviado a um servidor.
const menuButton = document.querySelector(".menu-toggle");
const mainNav = document.querySelector(".site-nav");

if (menuButton && mainNav) {
  menuButton.addEventListener("click", () => {
    const expanded = menuButton.getAttribute("aria-expanded") === "true";
    menuButton.setAttribute("aria-expanded", String(!expanded));
    mainNav.classList.toggle("is-open", !expanded);
  });
}

const contrastButton = document.querySelector("#alternar-contraste");
const contrastStatus = document.querySelector("#contraste-status");
const contrastKey = "doabairro:alto-contraste";

try {
  if (localStorage.getItem(contrastKey) === "true") {
    document.body.classList.add("high-contrast");
    if (contrastButton) contrastButton.setAttribute("aria-pressed", "true");
  }
} catch {
  if (contrastStatus) {
    contrastStatus.textContent = "O navegador não permitiu salvar preferências.";
  }
}

if (contrastButton) {
  contrastButton.setAttribute("aria-pressed", String(document.body.classList.contains("high-contrast")));
}

if (contrastButton) {
  contrastButton.addEventListener("click", () => {
    const enabled = document.body.classList.toggle("high-contrast");
    contrastButton.setAttribute("aria-pressed", String(enabled));
    try {
      localStorage.setItem(contrastKey, String(enabled));
      if (contrastStatus) contrastStatus.textContent = enabled
        ? "Alto contraste ativado e salvo neste navegador."
        : "Alto contraste desativado.";
    } catch {
      if (contrastStatus) {
        contrastStatus.textContent = "Preferência alterada, mas não foi possível salvá-la neste navegador.";
      }
    }
  });
}

const searchForm = document.querySelector("#busca-projetos");
const searchInput = document.querySelector("#busca");
const searchStatus = document.querySelector("#busca-feedback");
const projectCards = [...document.querySelectorAll(".project-card[data-search]")];
const emptyState = document.querySelector("#busca-vazia");

function normalizeText(value) {
  return value.toLocaleLowerCase("pt-BR").normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function filterProjects(query) {
  const term = normalizeText(query.trim());
  let visible = 0;
  for (const card of projectCards) {
    const matches = !term || normalizeText(card.dataset.search).includes(term);
    card.hidden = !matches;
    if (matches) visible += 1;
  }
  if (emptyState) emptyState.hidden = visible !== 0;
  if (searchStatus) {
    searchStatus.textContent = term
      ? `${visible} iniciativa(s) de exemplo encontrada(s).`
      : "";
  }
}

if (searchForm && searchInput) {
  searchForm.addEventListener("submit", (event) => {
    event.preventDefault();
    filterProjects(searchInput.value);
  });
}

const contactForm = document.querySelector("#form-contato");
const draftStatus = document.querySelector("#rascunho-status");
const formStatus = document.querySelector("#form-status");
const draftKey = "doabairro:rascunho-contato";

if (contactForm) {
  const fields = [...contactForm.querySelectorAll("[data-validate]")];

  function showFieldError(field, message) {
    const error = document.querySelector(`#${field.id}-erro`);
    field.setAttribute("aria-invalid", message ? "true" : "false");
    if (error) error.textContent = message;
  }

  function validateField(field) {
    let message = "";
    if (field.type === "checkbox" && !field.checked) {
      message = "Marque esta opção para continuar.";
    } else if (field.required && !field.value.trim()) {
      message = "Este campo é obrigatório.";
    } else if (field.type === "email" && field.value && !field.validity.valid) {
      message = "Informe um e-mail válido.";
    } else if (field.name === "mensagem" && field.value.trim().length < 10) {
      message = "Escreva pelo menos 10 caracteres.";
    }
    showFieldError(field, message);
    return !message;
  }

  function saveDraft() {
    const draft = Object.fromEntries(new FormData(contactForm).entries());
    const consent = contactForm.elements.namedItem("consentimento");
    draft.consentimento = consent.checked;
    try {
      localStorage.setItem(draftKey, JSON.stringify(draft));
      if (draftStatus) draftStatus.textContent = "Rascunho salvo apenas neste navegador.";
    } catch {
      if (draftStatus) draftStatus.textContent = "Não foi possível salvar o rascunho neste navegador.";
    }
  }

  try {
    const savedDraft = localStorage.getItem(draftKey);
    if (savedDraft) {
      const draft = JSON.parse(savedDraft);
      for (const [name, value] of Object.entries(draft)) {
        const field = contactForm.elements.namedItem(name);
        if (field && field.type === "checkbox") field.checked = Boolean(value);
        else if (field) field.value = value;
      }
      if (draftStatus) draftStatus.textContent = "Rascunho recuperado deste navegador.";
    }
  } catch {
    if (draftStatus) draftStatus.textContent = "Não foi possível recuperar o rascunho salvo.";
  }

  const projectTopic = new URLSearchParams(window.location.search).get("assunto");
  if (["alimentacao", "animais", "agasalhos"].includes(projectTopic)) {
    const topicSelect = contactForm.elements.namedItem("assunto");
    if (topicSelect) topicSelect.value = "doacao";
  }

  contactForm.addEventListener("input", (event) => {
    const field = event.target;
    if (field.matches("[data-validate]")) validateField(field);
    saveDraft();
  });
  contactForm.addEventListener("change", saveDraft);
  contactForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const invalidFields = fields.filter((field) => !validateField(field));
    if (invalidFields.length) {
      if (formStatus) {
        formStatus.textContent = "Revise os campos destacados antes de continuar.";
        formStatus.classList.add("error");
      }
      invalidFields[0].focus();
      return;
    }
    if (formStatus) {
      formStatus.textContent = "Validação concluída. Este protótipo não transmite sua mensagem; entre em contato diretamente com a iniciativa antes de doar.";
      formStatus.classList.remove("error");
    }
    try {
      localStorage.removeItem(draftKey);
      if (draftStatus) draftStatus.textContent = "Rascunho removido deste navegador.";
    } catch {
      if (draftStatus) draftStatus.textContent = "Não foi possível remover o rascunho deste navegador.";
    }
    contactForm.reset();
    fields.forEach((field) => showFieldError(field, ""));
  });
}

const faqForm = document.querySelector("#faq-form");
const faqInput = document.querySelector("#faq-pergunta");
const faqAnswer = document.querySelector("#faq-resposta");

if (faqForm && faqInput && faqAnswer) {
  faqForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const question = faqInput.value.trim().toLocaleLowerCase("pt-BR");
    if (!question) {
      faqAnswer.textContent = "Digite uma pergunta para receber uma resposta.";
    } else if (question.includes("doa") || question.includes("roupa") || question.includes("alimento")) {
      faqAnswer.textContent = "Confira os exemplos na página Projetos e combine a entrega diretamente com a iniciativa. O site não recebe doações.";
    } else if (question.includes("contato") || question.includes("equipe")) {
      faqAnswer.textContent = "Use o formulário de Contato para registrar um rascunho neste navegador. Ele ainda não envia mensagens.";
    } else if (question.includes("segur") || question.includes("confirm")) {
      faqAnswer.textContent = "Confirme a identidade da organização, o item necessário e o local de entrega por um canal confiável antes de doar.";
    } else {
      faqAnswer.textContent = "Ainda não tenho uma resposta para isso. Consulte as páginas Projetos, Acessibilidade e Contato.";
    }
  });
}
