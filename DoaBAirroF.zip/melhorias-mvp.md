# Melhorias em relação ao material disponível

## Antes e depois observados nesta pasta

| Antes (arquivos encontrados na pasta de trabalho) | Depois desta revisão |
|---|---|
| Havia apenas `index.html`; os links do menu para páginas adicionais não abriam. | Foram criadas as nove páginas restantes e o menu passou a ser compartilhado visualmente entre elas. |
| Campo de busca e botão não filtravam conteúdo. | Busca passou a filtrar cartões demonstrativos na Home, Projetos e Notícias. |
| Não havia arquivo JavaScript nem persistência local. | `app.js` implementa menu móvel, FAQ por regras, alto contraste e rascunho em `localStorage`. |
| Não existia formulário validado. | Página Contato tem validação, mensagens ligadas aos campos e indicação clara de que não envia os dados. |
| Folha de estilos usava cores sem declarar as variáveis correspondentes. | `style.css` centraliza tokens de cor, tipografia, foco, layout responsivo e redução de movimento. |
| Não havia documentação de entrega organizada. | Pasta `docs/` inclui escopo, diário, IA, orçamento, melhorias, testes e checklist. |

## Feedback da primeira entrega

Segundo a equipe, não há apontamentos específicos por escrito disponíveis para relacionar nesta entrega. A tabela acima registra somente diferenças verificáveis entre os arquivos encontrados e a versão atual; **não comprova que todo o feedback do MVP foi corrigido**. Se a equipe localizar ou receber a devolutiva, adicionar cada ponto real abaixo e anexar evidência.

| Ponto apontado pelo professor | Correção feita | Evidência antes/depois |
|---|---|---|
| Nenhum apontamento específico disponível até o momento | Não é possível confirmar correções específicas sem a devolutiva | Pendente de confirmação com a equipe/professor |

Não apresentar as diferenças do código como se fossem respostas a comentários específicos do professor.
