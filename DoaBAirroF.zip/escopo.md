# Escopo e critérios de aceitação

## Problema e público

O projeto propõe facilitar o encontro entre moradores que desejam ajudar e iniciativas comunitárias locais. O público inclui moradores, voluntários, organizações e pessoas com deficiência.

## Objetivos mensuráveis

| Objetivo | Critério de aceitação | Situação nesta versão |
|---|---|---|
| Apresentar um site com 10 páginas | 10 arquivos HTML, todos com navegação principal interligada | Implementado; 10 páginas passaram no Nu HTML Checker em 13/11/2026 |
| Facilitar a busca por temas | Busca filtra os exemplos na página inicial, Projetos e Notícias | Implementado no navegador |
| Oferecer interação funcional | Menu móvel, alto contraste, FAQ por regras e formulários com eventos | Implementado; testar nos navegadores-alvo |
| Validar contato e salvar rascunho | Mensagens e destaque visual de erros; rascunho persiste em `localStorage` | Implementado; sem envio ao servidor |
| Atender a práticas de acessibilidade | Semântica, teclado, foco visível, `lang`, rótulos e estados anunciados | Implementado parcialmente; auditoria externa/manual pendente |
| Relacionar a proposta aos ODS | Explicar ODS relevantes e citar fonte oficial | Implementado; não há métricas de impacto real |
| Publicar com HTTPS | Site publicado e dez rotas/recursos testados online | Pendente; não há URL de produção fornecida |
| Documentar equipe e evolução | Equipe, papéis, feedback do MVP, GitHub e evidências registrados | Nomes/RA registrados; confirmar papéis; GitHub e evidências ainda pendentes; não há apontamentos específicos do MVP disponíveis |

## Fora do escopo atual / limitações

- Cadastro autenticado e verificação de organizações.
- Envio de mensagens a um servidor, pagamentos ou recebimento de doações.
- Dados reais de campanhas, métricas de impacto ou notícias atuais.
- Assistente generativo. A FAQ é uma pequena árvore de regras explícitas.
- Deploy, integração contínua, histórico de contribuições e pull request: dependem de acesso e ação no GitHub.

## Critérios de segurança e transparência

Os projetos são identificados como exemplos fictícios; o site orienta a confirmar organizações e necessidades; o formulário avisa que os dados permanecem no navegador e não são enviados.
