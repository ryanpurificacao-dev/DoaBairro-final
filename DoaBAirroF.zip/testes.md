# Testes e evidências

Registrar a data, navegador, dispositivo e evidência (captura, saída ou URL) de cada teste executado. Não marcar como aprovado sem executar.

| Teste | Resultado esperado | Status |
|---|---|---|
| Estrutura das 10 páginas e links locais | Dez HTMLs, landmarks principais, IDs únicos e links locais existentes | Aprovado por verificação local em 13/11/2026 |
| Sintaxe de `app.js` | Arquivo analisado pelo JavaScript for Automation do macOS | Aprovado em 13/11/2026 |
| Busca por “Tatuapé” | Filtra cartões demonstrativos mesmo com diferença de acento | Aprovado no navegador |
| Layout desktop e celular | Dez páginas sem rolagem horizontal; menu móvel recolhido inicialmente | Aprovado no navegador; viewport móvel de referência 390 px |
| Menu e link para pular conteúdo por teclado | Link de pulo e botão recebem foco; Enter ativa o link e abre o menu | Aprovado no navegador |
| Formulário vazio/inválido | Mensagens, `aria-invalid`, destaque e foco no primeiro campo inválido | Aprovado no navegador |
| Formulário válido | Confirma a validação sem afirmar que enviou a mensagem | Aprovado no navegador |
| Rascunho em `localStorage` | Campo foi salvo, restaurado após recarga e removido ao validar | Aprovado no navegador |
| Preferência de contraste | Ativação persiste após recarregar neste navegador | Pendente de teste manual |
| HTML W3C | As 10 páginas sem erros nem avisos | Aprovado no [Nu HTML Checker](https://validator.w3.org/nu/) em 13/11/2026 |
| URL publicada | HTTPS e todas as páginas/recursos funcionam online | Pendente de deploy |
| Leitor de tela e contraste | Fluxos básicos e contraste verificados com tecnologia assistiva | Revisão manual pendente |

## Evidências a anexar

- Capturas da página inicial em [desktop](./home-desktop.png) e [celular](./home-celular.png).
- Nu HTML Checker em 13/11/2026: 10 páginas verificadas, 0 erros e 0 avisos.
- A fonte HTML da apresentação também passou no Nu HTML Checker sem erros ou avisos.
- Registrar a URL e capturas do formulário com erro/acerto e da persistência quando o ambiente de apresentação estiver definido.
- URL HTTPS funcional e captura de cada página publicada.
- Resultado da revisão manual por teclado e, se possível, leitor de tela.
