# Diário de bordo

## 13/11/2026 — Revisão para a segunda entrega

- **Situação encontrada:** a cópia local continha a página inicial e uma folha CSS; o menu apontava para páginas que não existiam. A busca era apenas visual e não havia JavaScript nem documentação organizada.
- **Decisão:** manter o tema DoaBairro e a identidade verde, completar as dez páginas pedidas, criar interações externas em `app.js` e centralizar o estilo responsivo em `style.css`.
- **Implementado:** navegação entre dez páginas; busca de exemplos; menu móvel; alto contraste persistido; FAQ simples por regras; formulário com validação, mensagens de erro, destaque visual e rascunho em `localStorage`; conteúdo sobre ODS, acessibilidade e hospedagem.
- **Transparência:** nomes, pedidos e locais de projetos são apresentados como fictícios. O formulário não envia dados, a FAQ não é generativa e o site ainda não está publicado.
- **Equipe:** foram registrados os sete integrantes e uma divisão proposta de responsabilidades; cada pessoa deve confirmar o papel e as tarefas que realmente executou.
- **Feedback do MVP:** a equipe informou que não tem apontamentos específicos por escrito disponíveis. As mudanças foram comparadas com os arquivos encontrados, sem atribuir a elas uma devolutiva que não foi fornecida.
- **Documentação criada:** escopo, plano de orçamento, registro de IA, melhorias observadas e checklist de testes/entrega.
- **Validação local:** as dez páginas e seus links passaram pela verificação estrutural; busca, formulário inválido/válido, persistência de rascunho após recarga, menu/teclado e layout móvel foram exercitados no navegador. Capturas estão em `docs/`.
- **Validação local:** em 13/11/2026, as dez páginas passaram no Nu HTML Checker sem erros ou avisos.
- **Validação pendente:** leitor de tela/contraste, deploy e revisão final da equipe.
- **Pendências:** confirmar os papéis e contribuições; publicar e testar URL HTTPS; criar branch/PR e confirmar commits de cada integrante; produzir slides, capturas e `.zip`; preencher o `.txt` de equipe e enviar no Blackboard. Se forem recebidos apontamentos do MVP, relacioná-los às correções e evidências.

### Decisões técnicas que a equipe deve saber explicar

- O JavaScript é carregado por `<script src="app.js" defer>`; assim, os elementos HTML já existem quando os eventos são registrados.
- `localStorage` guarda somente o rascunho do formulário e a preferência de alto contraste neste navegador; não substitui servidor nem envio de mensagem.
- O filtro compara o termo digitado com atributos `data-search` dos cartões e oculta os que não combinam.
- A validação verifica campos obrigatórios, e-mail, tamanho mínimo da mensagem e confirmação; erros são ligados aos campos por `aria-describedby`.
- A FAQ responde por palavras-chave com regras `if/else`. Ela não chama serviços externos nem gera texto livre.
