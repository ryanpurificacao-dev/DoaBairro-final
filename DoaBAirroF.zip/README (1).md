# DoaBairro

Projeto acadêmico demonstrativo de uma plataforma para aproximar moradores e iniciativas comunitárias. Esta versão não verifica organizações, não recebe doações e não envia os dados do formulário a um servidor.

## Como executar

Abra `index.html` em um navegador moderno. Não há dependências nem etapa de compilação. O mapa incorporado precisa de conexão com a internet; busca, menu, alto contraste, FAQ e rascunho do formulário funcionam localmente.

## Páginas

1. Início (`index.html`)
2. Sobre (`sobre.html`)
3. Projetos (`projetos.html`)
4. Impacto e ODS (`impacto.html`)
5. Acessibilidade (`acessibilidade.html`)
6. Galeria (`galeria.html`)
7. Mídia (`midia.html`)
8. Notícias e dicas (`noticias.html`)
9. Contato e voluntariado (`contato.html`)
10. Orçamento e hospedagem (`orcamento_hospedagem.html`)

## Funcionalidades

- Busca demonstrativa de iniciativas e dicas.
- Menu recolhível em telas menores e navegação por teclado.
- Preferência de alto contraste salva no `localStorage`.
- Formulário com validação em JavaScript e rascunho salvo apenas no navegador.
- FAQ com respostas por regras explícitas; não é uma IA generativa.
- Layout responsivo com HTML semântico e recursos de acessibilidade.

## Equipe e publicação

- Pedro Henrrique Araujo — RA 47920742
- Ryan da Purificação de Oliveira — RA 47508442
- João Victor Gomes Santana — RA 47699736
- Adrian Guilherme Viera Gomes — RA 47666188
- Matheus Masayuki — RA 47354267
- Leonardo Fonseca — RA 47354313
- Marcelo Eduardo de Souza Junior — RA 47128828
- Lista para entrega: [integrantes.txt](./integrantes.txt)
- URL publicada com HTTPS: **[pendente de publicação]**
- Repositório GitHub: **[pendente]**
- Branch e pull request: **[registrar após criar no GitHub]**

A divisão de responsabilidades é uma proposta para a equipe confirmar em [docs/README.md](./docs/README.md). Não afirmar que houve deploy ou PR antes de concluir esses passos. A proposta de hospedagem está em [orcamento_hospedagem.html](./orcamento_hospedagem.html) e [docs/orcamento.md](./docs/orcamento.md).

## Documentação da entrega

Consulte [docs/README.md](./docs/README.md) para escopo, diário de bordo, uso de IA, melhorias do MVP, orçamento, testes, fonte da apresentação e checklist dos arquivos de entrega.
